package com.example.recipe.Listeners;

import com.example.recipe.Models.RecipeDetailsResponse;
public interface RecipeDetailsListener {
    public void didFetch(RecipeDetailsResponse response, String message);
    public void didError(String message);
}