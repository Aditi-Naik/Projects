package com.example.recipe.Models;

public class Temperature {
    public double number;
    public String unit;
}
