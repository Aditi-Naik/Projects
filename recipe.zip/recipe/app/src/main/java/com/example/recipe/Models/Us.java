package com.example.recipe.Models;

public class Us {
    public double amount;
    public String unitShort;
    public String unitLong;
}
