package com.example.recipe.Models;

public class Length {
    public int number;
    public String unit;
}
