<?php 
    include 'connection.php';
    error_reporting(0);
    $Company_Name = $_POST['Company_Name'];
    $HRName = $_POST['HRName'];
    $Email=$_POST['Email'];
    $Address=$_POST['Address'];
    $conn=new mysqli('localhost','root','','test1');
    if($conn->connect_error){
        die('REGISTRATION FAILED: '.$conn->connect_error);
     }
     else{
     $query = "SELECT * FROM company";
    $data = mysqli_query($conn, $query);
    $total = mysqli_num_rows($data);
    if($total != 0)
    {
        ?>
        <body>
        <h1>COMPANY DETAILS</h1>

        <table style = "text-align: center";>
            <tr id = "header">
                <th>Company Name</th>
                <th>HR Name</th>
                <th>Email</th>
                <th>Address</th>
            </tr>
        <?php

        while($result = mysqli_fetch_assoc($data))       
        {
            echo "<tr>
                    <td>".$result['Company_Name']."</td>
                    <td>".$result['HRName']."</td>
                    <td>".$result['Email']."</td>
                    <td>".$result['Address']."</td>
                </tr> ";
        }
    }
    else{
        echo "No Records found";
    }
}
    ?>
    </body>
    </table>
    <style>
            body{
                padding: 0;
                margin: 0;
                font-family: Verdana, Geneva, Tahoma, sans-serif;
            }
            table{
                position: absolute;
                left: 50%;
                top: 50%;
                transform: translate(-50%,-50%);
                border-collapse: collapse;
                width: 800px;
                height: 200px;
                border: 1px solid #bdc3c7;
                box-shadow: 2px 2px 12px rgba(0,0,0,0.2), -1px -1px 8px rgba(0,0,0,0.2);
            }
            tr {
                transition: all .2s ease-in;
                cursor: pointer;
            }
            th,td{
                padding: 12px;
                text-align: left;
                border-bottom: 1px solid #ddd; 
            }
            #header{
                background-color: #16a085;
                color: #fff;
            }
            h1{
                font-weight: 600;
                text-align: center;
                background-color:#16a085;
                color: #fff;
                padding: 10px 0px;
            }
            tr:hover{
                background-color: #f5f5f5;
                transform: scale(1.02);
                box-shadow: 2px 2px 12px rgba(0,0,0,0.2), -1px -1px 8px rgba(0,0,0,0.2);
            }
        </style>