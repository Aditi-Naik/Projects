<?php
    include("connection.php");
    $USN = $_POST['USN'];
    $query = "DELETE FROM registration WHERE USN = $USN";
    $data = mysqli_query($conn, $query);
    if($data)
    {
        echo "<script>alert('Record Deleted')</script>";
        ?>
        <meta http-equiv="Refresh" content="0; url=adminoptions.html">
        <?php
    }
    else{
        echo "<font color='red'>Sorry, Delete process failed";
    }
?> 