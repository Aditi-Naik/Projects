<?php
    $Name = $_POST['Name'];
    $email=$_POST['email'];
    $PhoneNumber=$_POST['PhoneNumber'];
    $gender=$_POST['gender'];
    $Password=$_POST['Password'];
    $conn=new mysqli('localhost','root','','test1');
    if($conn->connect_error){
        die('REGISTRATION FAILED: '.$conn->connect_error);
     }
     else{
       
         $stmt=$conn->prepare("insert into adminreg(Name, email, PhoneNumber, gender, Password)
         VALUES(?, ?, ?, ?, ?)");
         $stmt->bind_param("ssiss",$Name, $email, $PhoneNumber, $gender, $Password);
         $stmt->execute();
         echo "<script>alert('Registration Successfull!!..')</script>";
        ?>
        <meta http-equiv="Refresh" content="0;>
        <?php
        $stmt->close();
        $conn->close();
    }
?>