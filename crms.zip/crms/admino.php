<?php
    include 'connection.php';

    if(isset($_POST['Add_Student'])){
        header("Location:addstudent.html");
    }

    if(isset($_POST['view_Student'])){
        header("Location:viewstudent.php");
    }

    if(isset($_POST['Remove_student'])){
        header("Location:delete student.html");
    }

    if(isset($_POST['Add_company'])){
        header("Location:add company.html");
    }

    if(isset($_POST['view_company'])){
        header("Location:viewcompany.php");
    }

    if(isset($_POST['Remove_company'])){
        header("Location:delete company.html");
    }

    if(isset($_POST['back_to_home'])){
        echo "<script>alert('Log Out Successfull....')</script>";
        ?>
        <meta http-equiv="Refresh" content="0; url=front.html">
        <?php
    }