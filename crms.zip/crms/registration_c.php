<?php
   error_reporting(0);
    $Company_Name= $_POST['Company_Name'];
    $HRName = $_POST['HRName'];
    $Email=$_POST['Email'];
    $Address=$_POST['Address'];
    $Password=$_POST['Password'];
    $conn=new mysqli('localhost','root','','test1');
    if($conn->connect_error){
        die('REGISTRATION FAILED: '.$conn->connect_error);
     }
     else{
       
         $stmt=$conn->prepare("insert into company(Company_Name, HRName, Email, Address, Password)
         VALUES(?, ?, ?, ?,?)");
         $stmt->bind_param("sssss",$Company_Name, $HRName, $Email,$Address,$Password);
         $stmt->execute();
         echo "<script>alert('Registration Successfull!!..')</script>";
        ?>
        <meta http-equiv="Refresh" content="0; url=adminoptions.html">
        <?php
        $stmt->close();
        $conn->close();
    }
?>