<?php

include 'connection.php';
    error_reporting(0);
    $Email = $_POST['Email'];
    $Password = $_POST['Password'];
    // $con = new mysqli("localhost","root","","test1");
    if($conn->connect_error)
    {
       die("Failed to connect: ".$conn->connect_error);
    }
    else
    {
        $stmt = $conn->prepare("select * from registration where Email=?");
        $stmt->bind_param("s", $Email);
        $stmt->execute();
        $stmt_result = $stmt->get_result();
        if($stmt_result->num_rows > 0)
        {
            $data=$stmt_result->fetch_assoc();
            if($data['Password'] == $Password) 
            {
             echo "<script>alert('Login Successful')</script>";
             ?>
             <meta http-equiv="Refresh" content="0; url=studentdisplay.html">
             <?php
            }
            else
            {
                echo"<script>alert('Invalid Email-id or Password')</script>";
                ?>
                <meta http-equiv="Refresh" content="0; url=Student.html">
                <?php
            }
        }
        else
        {
            echo"<script>alert('Invalid Email-id or Password')</script>";
                ?>
                <meta http-equiv="Refresh" content="0; url=Student.html">
                <?php
        }
    }
    
?> 