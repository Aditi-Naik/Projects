<?php
   error_reporting(0);
    $USN = $_POST['USN'];
    $StudentName = $_POST['StudentName'];
    $Email=$_POST['email'];
    $PhoneNumber=$_POST['PhoneNumber'];
    $gender=$_POST['gender'];
    $CGPA=$_POST['CGPA'];
    $Password=$_POST['Password'];
    $conn=new mysqli('localhost','root','','test1');
    if($conn->connect_error){
        die('REGISTRATION FAILED: '.$conn->connect_error);
     }
     else{
       
         $stmt=$conn->prepare("insert into registration(USN, StudentName, Email, PhoneNumber, gender, CGPA, Password)
         VALUES(?, ?, ?, ?, ?, ?, ?)");
         $stmt->bind_param("sssisss",$USN, $StudentName, $Email, $PhoneNumber, $gender, $CGPA, $Password);
         $stmt->execute();
         echo "<script>alert('Registration Successfull!!..')</script>";
        ?>
        <meta http-equiv="Refresh" content="0; url=viewstudent.php">
        <?php
        $stmt->close();
        $conn->close();
    }
?>